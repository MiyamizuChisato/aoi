import{_ as e,c,o as n}from"./index-794a8af2.js";const o={};function r(t,s){return n(),c("div",null," 123 ")}const a=e(o,[["render",r]]);export{a as default};
