import{_ as r}from"./index-794a8af2.js";const e={};function n(c,t){return null}const s=r(e,[["render",n]]);export{s as default};
